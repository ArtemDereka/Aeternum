let menu = document.getElementById('menu')
let hamburger = document.getElementById('hamburger')


hamburger.addEventListener('click', function () {
    console.log('ggggg')
    menu.classList.toggle('display_none_Mobile')
   
})