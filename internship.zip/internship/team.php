<?php require ' upANDdown/header.php'; ?>

    <main class="team">
        <section class="team__contact">
            <div class="team__contact_img">
                <div class="team__contact_text_holder">
                    <p class="team__contact_txt">unique public</p>
                    <p class="team__contact_txt">and private</p>
                    <p class="team__contact_txt">marcet</p>
                    <p class="team__contact_txt">experience.</p>
                </div>
            </div>
            <div class="team__contact_block">
                <div class="team__contact_field">
                    <p class="team__contact_why">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                        nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam
                        erat, sed diam voluptua. At vero eos et accusam et justo duo dolores
                        et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                        Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur
                        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
                        dolore magna aliquyam erat, sed diam voluptua. At
                    </p>
                    <button class="team__contact_btn">CONTACT US</button>
                </div>
                <div class="block__grey"></div>
            </div>
            <div class="block__green"></div>
        </section>

        <section class="team__about">
            <div class="container">
                <h2 class="team__about_name">OUR TEAM</h2>
                <div class="team__about_holder">
                    <div class="team__about_person">
                        <div class="team__person_img_holder">
                            <div class="block__green_small"></div>
                            <img src="/images/Vegard Soeraunet_0010.png" alt="" class="team__person_img">
                        </div>
                        <h3 class="team__about_person_name">VEGARD SØRAUNET</h3>
                        <p class="team__about_person_position">Investment Director and Partner</p>
                        <p class="team__about_person_text">About with education, key experience and sectors</p>
                    </div>
                    <div class="team__about_person">                   
                        <div class="team__person_img_holder">
                            <div class="block__grey_small"></div>
                            <img src="/images/Vegard Soeraunet_0010.png" alt="" class="team__person_img">
                        </div>
                        <h3 class="team__about_person_name">VEGARD SØRAUNET</h3>
                        <p class="team__about_person_position">Investment Director and Partner</p>
                        <p class="team__about_person_text">About with education, key experience and sectors</p>
                    </div>
                    <div class="team__about_person">
                        <div class="team__person_img_holder">
                            <div class="block__darkgrey_small"></div>
                            <img src="/images/Vegard Soeraunet_0010.png" alt="" class="team__person_img">
                        </div>
                        <h3 class="team__about_person_name">VEGARD SØRAUNET</h3>
                        <p class="team__about_person_position">Investment Director and Partner</p>
                        <p class="team__about_person_text">About with education, key experience and sectors</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php require ' upANDdown/footer.php'; ?> 

</body>
</html>